// index.js
Component({
  data: {
    motto: 'Hello World'
  },
  methods: {
    // 事件处理函数

  },

  callBack(data) {
	console.log(data) // data为B页面返回时传来的参数
}
})
